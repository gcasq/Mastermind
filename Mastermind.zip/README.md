# Mastermind

Este trabalho requer que eu implemente o jogo chamado Mastermind (no Brasil, conhecido como Senha) utilizando linguagens de desenvolvimento Web, e usando os personagens de Game of Thrones no lugar das cores. 

Regras do jogo, de acordo com o que vou implementar, disponível em https://pt.wikihow.com/Jogar-Senha:

- O jogador deve adivinhar o código que o computador inventar, o qual ficará colocado na fileira oculta pintada de preto (assim que se apertar o botão "Iniciar Jogo"). Este código será gerado automatica e randomicamente, permitindo repetições de personagens que compoem a senha. 

-O tabuleiro inteiro é composto pela coluna oculta (4 pinos) e 8 colunas do jogador, composta pelos 4 pinos de palpite, e 4 pinos menores que vão auxiliar o jogador a saber o quão próximo o palpite dele está correto.

-Assim que o jogador terminar o seu palpite de uma fileira, serão coloridos os pinos das dicas. Se houverem x pinos vermelhos, significa que existem x personagens corretos, em suas posições corretas, e se houverem y pinos pretos, significa que existem y personagens corretos colocados, porém em posições incorretas. 